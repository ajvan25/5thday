-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Erstellungszeit: 25. Mrz 2026 um 13:50
-- Server-Version: 8.4.7
-- PHP-Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `library`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(40) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `genre` varchar(30) DEFAULT NULL,
  `picture` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;

--
-- Daten für Tabelle `books`
--

INSERT INTO `books` (`book_id`, `title`, `author`, `year`, `genre`, `picture`) VALUES
(1, 'The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Tragedy', 'https://plus.unsplash.com/premium_photo-1774002133542-bbef3f2cc3d5?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),
(2, '1984', 'George Orwell', 1949, 'Dystopian', 'https://images.unsplash.com/photo-1678082632363-a1'),
(3, 'Pride and Prejudice', 'Jane Austen', 1813, 'Romance', 'https://images.unsplash.com/photo-1714146999585-8ceabe6df9f6?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8UHJpZGUlMjBhbmQlMjBQcmVqdWRpY2UlMjBidWNofGVufDB8fDB8fHww'),
(4, 'Moby Dick', 'Herman Melville', 1851, 'Adventure', 'https://media.istockphoto.com/id/2188609814/de/foto/moby-dick.webp?a=1&b=1&s=612x612&w=0&k=20&c=JJ58N6zatMGcZbITh4--b_UwOG7WO_gLh-u0khEwlmY='),
(5, 'Frankenstein', 'Mary Shelley', 1818, 'Horror', 'https://images.unsplash.com/photo-1601212267463-b74ef53c48e4?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8RnJhbmtlbnN0ZWluJTIwYnVjaHxlbnwwfHwwfHx8MA%3D%3D'),
(6, 'To Kill a Mockingbird', 'Harper Lee', 1960, 'Southern Gothic', 'https://images.unsplash.com/photo-1672317535351-54ed5ebf791d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8VG8lMjBLaWxsJTIwYSUyME1vY2tpbmdiaXJkfGVufDB8fDB8fHww'),
(7, 'The Catcher in the Rye', 'J.D. Salinger', 1951, 'Fiction', 'https://images.unsplash.com/photo-1577720643252-4b2814e04d7b?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fFRoZSUyMENhdGNoZXIlMjBpbiUyMHRoZSUyMFJ5ZXxlbnwwfHwwfHx8MA%3D%3D'),
(8, 'Brave New World', 'Aldous Huxley', 1932, 'Dystopian', 'https://images.unsplash.com/photo-1664793937878-4b663ff216f3?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGJyYXZlJTIwd29ybGR8ZW58MHx8MHx8fDA%3D');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
